const products = [
  {name: "Laptop", price: 50000, image: "images/laptop.jpg"},
  {name: "Mobile", price: 20000, image: "images/mobile.jpg"},
  {name: "Headphones", price: 3000, image: "images/headphones.jpg"},
  {name: "Smart Watch", price: 7000, image: "images/smartwatch.jpg"}
];

let cart = [];

const buttonsDiv = document.getElementById("buttons");
products.forEach(prod => {
  const btn = document.createElement("button");
  btn.innerText = "Add " + prod.name;
  btn.onclick = () => addItem(prod);
  buttonsDiv.appendChild(btn);
});

function addItem(product){
  const existing = cart.find(p => p.name === product.name);
  if(existing) existing.qty++;
  else cart.push({...product, qty: 1});
  renderCart();
}

function removeItem(index){
  cart.splice(index,1);
  renderCart();
}

function renderCart(){
  const cartDiv = document.getElementById("cart");
  cartDiv.innerHTML = "";
  let total = 0;
  cart.forEach((item,index)=>{
    total += item.price*item.qty;
    const div = document.createElement("div");
    div.className = "cart-item";
    div.innerHTML = `
      <img src="${item.image}" alt="${item.name}">
      <div class="cart-item-details">
        <div>${item.name}</div>
        <div>₹${item.price} x ${item.qty}</div>
        <button onclick="removeItem(${index})">Remove</button>
      </div>
    `;
    cartDiv.appendChild(div);
  });
  document.getElementById("total").innerText = "Total: ₹"+total;
}

function applyDiscount(){
  const discount = parseFloat(document.getElementById("discount").value);
  fetch("/CartWebApp/calculateTotal", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({cart, discount})
  })
  .then(res=>res.json())
  .then(data=>{
    document.getElementById("total").innerText="Total after discount: ₹"+data.total;
  });
}
