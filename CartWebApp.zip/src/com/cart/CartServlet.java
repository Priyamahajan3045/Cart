package com.cart;

import com.google.gson.Gson;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/calculateTotal")
public class CartServlet extends HttpServlet {
    static class Item {
        String name;
        double price;
        int qty;
    }

    static class RequestData {
        Item[] cart;
        double discount;
    }

    static class ResponseData {
        double total;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        BufferedReader reader = request.getReader();
        Gson gson = new Gson();
        RequestData data = gson.fromJson(reader, RequestData.class);

        double total = 0;
        if(data.cart != null) {
            for(Item item : data.cart){
                total += item.price * item.qty;
            }
        }

        total = total - (total * data.discount/100);

        ResponseData respData = new ResponseData();
        respData.total = total;

        response.setContentType("application/json");
        response.getWriter().write(gson.toJson(respData));
    }
}
